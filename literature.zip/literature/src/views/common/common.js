/**
 * 共用JS函数
 */
import { CodeToText, TextToCode } from 'element-china-area-data'

export const CodeToAddress = function(codes){
  let address = '';
  for(let value of codes){  
    address += CodeToText[value];
  }
  return address;
}

export const AddressToCode = function(addr){
  let code = [];
  for(let value of codes){  
    code.push(TextToCode[value])
  }
  return code;
}

export const formatDate = function (now) {
  now =new Date(now)
  let year= now.getFullYear();
  let month=now.getMonth()+1;     
  let date=now.getDate();    
  return year+"-"+month+"-"+date; 
}

export const hasPermission = function (permission) {
  let auth = sessionStorage.getItem("auth").split(',');
  let result = false; 
  permission.forEach(function(e){
    if($.inArray(e,auth)!=-1){ 
      result = true;
    }
  })
  return result;
}

// 创建权限
export const createPermission = function (permission) {
    let createPermission = {}
    createPermission.id = permission.id;
    createPermission.label = permission.label;
    let children = [];
    for(let i=1; i<5; i++) {
      switch(i)  {
        case 1:
          children.push({
            id: parseInt(permission.id)+1,
            label: '新增'
          });
          break;
        case 2:
          children.push({
            id: parseInt(permission.id)+2,
            label: '删除'
          })
          break;
        case 3:
          children.push({
            id: parseInt(permission.id)+3,
            label: '修改'
          })
          break;
        case 4:
          children.push({
            id: parseInt(permission.id)+4,
            label: '查看'
          })
          break;
        default:
            ;
      }
    }
    createPermission.children = children;
    return createPermission;
}