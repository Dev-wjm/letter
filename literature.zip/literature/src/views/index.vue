<template>
  <div>
    <div class="menu">
      <el-menu :default-active="activeIndex2" class="el-menu-demo" mode="horizontal"  @select="handleSelect"  background-color="#545c64" text-color="#fff" active-text-color="#ffd04b">
        <el-menu-item index="0">
          <img src="./images/logo2.png" alt="AdminX" style="padding-left: 10rem;">
        </el-menu-item>
        <el-menu-item index="1">在线书籍</el-menu-item>
        <el-menu-item index="2">推荐书籍</el-menu-item>
        <el-menu-item index="3">共享书单</el-menu-item>
        <el-menu-item index="4">留言区</el-menu-item> 
        <el-menu-item index="6" style="float: right;">登陆</el-menu-item>
        <el-menu-item index="7" style="float: right;">注册</el-menu-item> 
      </el-menu>
    </div>
      
    <div class="bottom-toolbar ofh">
      <el-row>
        <el-col :span="24">
          <div class="fr">
            <el-pagination
              @current-change="handleCurrentChange"
              :current-page="currentPage"
              :page-size="10"
              layout="total, prev, pager, next"
              :total="total">
            </el-pagination>
          </div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return { 
        activeIndex2: '1',
        input: '',
        tabPosition: 'left',
        labels: ['用户管理1','用户管理2','用户管理3','用户管理4'],
        bookList: ['书本1','书本2','书本3','书本4','书本5','书本6','书本7','书本8','书本9','书本10','书本1','书本1'], 
        currentDate: new Date(),
         //当前页码
        currentPage: 1,
        //数据总条目
        total: 0,
        //每页显示多少条数据
        length: 15
      };
    },
    methods: {
      handleSelect(key, keyPath) {
        console.log(key, keyPath);
      },
      handleCurrentChange() {

      }
    }
  }
</script>

<style scope>
  .menu {
    width: 100%
  }
  .el-menu {
    height: 5.3rem; 
  }
  .el-menu > .el-menu-item {
    height: 5.3rem;
    line-height: 5rem;
  }  
  
  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }
  .el-carousel__item:nth-child(2n+1) {
    background-color: #d3dce6;
  }


  .time {
    font-size: 13px;
    color: #999;
  }
  .bottom {
    margin-top: 13px;
    line-height: 12px;
  }
  .button {
    padding: 0;
    float: right;
  }
  .image {
    width: 10%;
    display: block;
  }
  .clearfix:before,
  .clearfix:after {
      display: table;
      content: "";
  }
  .clearfix:after {
      clear: both
  }

  .fr { 
    text-align: center;
    float: none;
  }
</style>
