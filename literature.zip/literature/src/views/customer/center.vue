<template>
  <div>
    <el-form>
      <el-row>
        <el-col>
          <el-form-item label="头像设置" prop="name">
            <el-upload
              class="avatar-uploader"
              action="https://jsonplaceholder.typicode.com/posts/"
              :show-file-list="false"
              :on-success="handleAvatarSuccess"
              :before-upload="beforeAvatarUpload">
              <img v-if="imageUrl" :src="imageUrl" class="avatar">
              <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
        </el-form-item>
        </el-col>
      </el-row>
      <el-form-item label="用户名:">
        <el-input v-model="username" placeholder="用户名" style="width: 400px;"></el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <router-link to="/upersonal">
        <el-button type="primary">修改信息</el-button>
      </router-link>
      <el-button type="primary" @click="updatePassword()">修改密码</el-button>
    </div>

    <el-dialog title="修改密码" :visible.sync="dialogFormVisible">
      <el-form>
        <el-form-item label="旧密码:">
          <el-input v-model="oldpassword" placeholder="旧密码" style="width: 400px;"></el-input>
        </el-form-item>
        <el-form-item label="新密码:">
          <el-input v-model="newpassword" placeholder="新密码" style="width: 400px;"></el-input>
        </el-form-item>
        <el-form-item label="确认密码:">
          <el-input v-model="newpassword" placeholder="确认密码" style="width: 400px;"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="updatePassword('change')">确 定</el-button>
      </div>
    </el-dialog> 
  </div>
</template>

<script>
  export default {
    data () {
      return {
        userid: '',
        username: '',
        oldpassword: '',
        newpassword: '',
        imageUrl: '',
        dialogFormVisible: false
      }
    },
    methods: {
      updatePassword(flag) {
        
        if(flag){
          // 更改密码
          this.dialogFormVisible = false;
        }else {
          this.dialogFormVisible = true;
        }
        
      },
      // 头像上传方法
      handleAvatarSuccess(res, file) {
        this.imageUrl = URL.createObjectURL(file.raw);
      },
      beforeAvatarUpload(file) {
        const isJPG = file.type === 'image/jpeg';
        const isLt2M = file.size / 1024 / 1024 < 2;

        if (!isJPG) {
          this.$message.error('上传头像图片只能是 JPG 格式!');
        }
        if (!isLt2M) {
          this.$message.error('上传头像图片大小不能超过 2MB!');
        }
        return isJPG && isLt2M;
      }
    }
  }
</script>

<style>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>