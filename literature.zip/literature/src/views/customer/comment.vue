<template>
  <div class="panel">
    
    <div class="panel-title">
      <span>评论详情</span>
      <div class="fr"></div>
    </div>
    <div class="panel-body" v-loading="load_data" element-loading-text="拼命加载中">
      <el-row>
        <el-col :span="16">
          <el-form label-width="100px">
            <el-form-item label="用户名:" prop="name">
              <el-input v-model="name" placeholder="请输入内容" style="width: 250px;"></el-input>
            </el-form-item>
            <el-form-item label="书名:" prop="name">
              <el-input v-model="name" placeholder="请输入内容" style="width: 250px;"></el-input>
            </el-form-item>
            <el-form-item label="评论时间:">
              <el-date-picker v-model="birthday" type="date" format="yyyy-MM-dd" :editable="false" @change="on_change_birthday" placeholder="选择生日"  style="width: 250px;">
              </el-date-picker>
            </el-form-item>
            <el-form-item label="评论内容" prop="desc">
              <el-input type="textarea" v-model="desc"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button @click="$router.back()">返回</el-button>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script type="text/javascript">

  export default{
    data(){
      return {
        name: 'TEST', 
        birthday: '2018-02-11',
        address: 'address', 
        desc: '', 
        load_data: false
        
      }
    },
    created(){
      
    },
    methods: {
      //获取数据
      get_form_data(){
        
      },
      //时间选择改变时
      on_change_birthday(val){
        this.$set(this.form, 'birthday', val)
      }
    }
  }
</script>

<style>
 
</style>

