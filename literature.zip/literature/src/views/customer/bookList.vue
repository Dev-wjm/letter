<template>
  <div id="userList">
    <div id="condition">
      <el-row>
        <el-col>
          <el-form ref="form" :inline="inline"  label-width="100px">
            <el-form-item label="书名:">
              <el-input v-model="username" placeholder="请输入内容" style="width: 250px;"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="search" >查询</el-button>
              <el-button @click="$router.back()">取消</el-button>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
    </div>
    <div class="panel">
      <!-- 顶部 -->
      <div class="panel-title">
        <span v-if="title" v-text="title"></span>
        <div class="fr">
          <el-button @click.stop="on_refresh" size="small">
            <i class="fa fa-refresh"></i>
          </el-button>
        </div>
      </div>

      <!-- 数据显示 -->
      <div class="panel-body">
        <el-table
          :data="table_data"
          v-loading="load_data"
          element-loading-text="拼命加载中"
          border
          @selection-change="on_batch_select"
          style="width: 100%;">
          <el-table-column
            type="selection"
            width="55">
          </el-table-column>
          <el-table-column
            prop="id"
            label="id"
            width="80">
          </el-table-column>
          <el-table-column
            prop="name"
            label="姓名"
            width="120">
          </el-table-column>
          <el-table-column
            prop="sex"
            label="性别"
            width="100">
            <template slot-scope="props">
              <span v-text="props.row.sex == 1 ? '男' : '女'"></span>
            </template>
          </el-table-column>
          <el-table-column
            prop="age"
            label="年龄"
            width="100">
          </el-table-column>
          <el-table-column
            prop="birthday"
            label="生日"
            width="120">
          </el-table-column>
          <el-table-column
            prop="zip"
            label="邮编"
            width="120">
          </el-table-column>
          <el-table-column
            prop="address"
            label="地址">
          </el-table-column>
          <el-table-column
            label="操作"
            width="180">
            <template slot-scope="props">
              <el-button type="danger" size="small" icon="delete" @click="delete_data(props.row)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
        <div class="bottom-toolbar ofh">
          <el-row>
            <el-col :span="24">
              <div class="fr">
                <el-pagination
                  @current-change="handleCurrentChange"
                  :current-page="currentPage"
                  :page-size="10"
                  layout="total, prev, pager, next"
                  :total="total">
                </el-pagination>
              </div>
            </el-col>
          </el-row>
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/javascript">
  
  export default{
    data(){
      return {
        inline: true,
        title: "用户数据",
        username: '',
        table_data: null,
        //当前页码
        currentPage: 1,
        //数据总条目
        total: 0,
        //每页显示多少条数据
        length: 15,
        //请求时的loading效果
        load_data: true,
        //批量选择数组
        batch_select: []
      }
    },
    
    created(){
      this.get_table_data()
    },
    methods: {
      
      //刷新
      on_refresh(){
        this.get_table_data()
      },
      //获取数据
      get_table_data(){
        this.table_data = [{
          id: 1,
          name: '@cname',
          sex: 1,//1男，2女
          age: 20,
          birthday: '2018-02-29',
          address: '@county(true)',
          zip: '@zip'
        }];
        this.load_data = false;
      },
      //单个删除
      delete_data(item){
        this.$confirm('此操作将删除该数据, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
          .then(() => {
            // this.load_data = true
            // this.$fetch.api_table.del(item)
            //   .then(({msg}) => {
            //     this.get_table_data()
            //     this.$message.success(msg)
            //   })
            //   .catch(() => {
            //   })
          })
          .catch(() => {
          })
      },
      //页码选择
      handleCurrentChange(val) {
        
      },
      //批量选择
      on_batch_select(val){
      },
      //批量删除
      on_batch_del () {

      },
      search() {

      }
    }
 }
</script>

