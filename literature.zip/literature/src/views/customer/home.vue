<template>
  <div class="view-page">
    <left-slide></left-slide>
    <div class="main-content ofh">
      <el-row>
        <el-col :span="24">
          <h-section></h-section>
          <div class="wrapper">
            <div class="pageContent">
              <el-row>
                <el-col :span="24">
                  <router-view></router-view>
                </el-col>
              </el-row>
            </div>
          </div>
          <v-footer></v-footer>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script type="text/javascript">
  import hSection from './headerSection'
  import leftSlide from './leftSlide'
  import vFooter from './footer'

  export default{
    name: 'AHome',
    components: {
      hSection,
      vFooter,
      leftSlide
    }
  }
</script>
