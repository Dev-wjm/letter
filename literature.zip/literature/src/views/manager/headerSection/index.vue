<template>
  <div class="header-section">
     <div class="menu-right" v-if="true">
      <div class="notification-menu">
        <el-dropdown trigger="click" class="notification-list">
          <div class="notification-btn">
            <img :src="get_user_info_user_avatar" alt="get_user_info.user.name"/>
            <span v-text="true"></span>
            <span class="icon"></span>
          </div>
          <el-dropdown-menu slot="dropdown" class="dropdown-menu">
            <el-dropdown-item class="dropdown-list">
              <router-link to="/acenter">
                <a href="javascript:" class="dropdown-btn" @click="user_click(0)">
                  <i class="icon fa fa-user"></i>
                  <span>个人中心</span>
                </a>
              </router-link>
            </el-dropdown-item>
            <el-dropdown-item class="dropdown-list">
              <a href="javascript:" class="dropdown-btn" @click="user_click(0)">
                <i class="icon fa fa-sign-out"></i>
                <span>安全退出</span>
              </a>
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
    </div>
  </div>
</template>
<script type="text/javascript">

  const USER_OUT = 0
  const USER_INFO = 1
  const USER_SETTING = 2

  export default{
    data () {
      return {
        get_user_info_user_avatar: ""
      }
    },
    methods: {
      //退出
      user_out(){
        // this.$root.$ruoter.push("/acenter")
        let _this = this;
        this.$confirm('此操作将退出登录, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          console.log(this.$root)
          this.$root.$ruoter.replace("/acenter")
        }).catch(() => {
          console.log("error")
        })
      },
      user_info() {
        
      },
      user_setting() {
        
      },
      user_click(type) {
        switch (type) {
          case USER_OUT :
            //退出
            this.user_out()
            break
          case USER_INFO:
          
            break
          case USER_SETTING:
            //设置
            break
        }
      }
    }
  }
</script>
