<template>
  <div class="left-side">
    <div class="left-side-inner">
      <router-link to="/" class="logo block">
        <img src="./images/logo.png" alt="AdminX">
      </router-link>
      <el-menu
        class="menu-box"
        theme="dark"
        router
        :default-active="$route.path">
        <div
          v-for="(item, index) in nav_menu_data"
          :key="index">
          <el-menu-item
            class="menu-list"
            v-if="typeof item.child === 'undefined'"
            :index="item.path">
            <i class="icon fa" :class="item.icon"></i>
            <span v-text="item.title" class="text"></span>
          </el-menu-item>
          <el-submenu
            :index="item.path"
            v-else>
            <template slot="title">
              <i class="icon fa" :class="item.icon"></i>
              <span v-text="item.title" class="text"></span>
            </template>
            <el-menu-item
              class="menu-list"
              v-for="(sub_item, sub_index) in item.child"
              :index="sub_item.path"
              :key="sub_index">
              <span v-text="sub_item.title" class="text"></span>
            </el-menu-item>
          </el-submenu>
        </div>
      </el-menu>
    </div>
  </div>
</template>
<script type="text/javascript">
  export default{
    name: 'slide',
    data(){
      return {
        nav_menu_data: [
          { title: "主页", path: "/home", icon: "fa-home"  }, 
          { title: "用户管理", path: "/table", icon: "fa-table",
            child: [
              { title: "用户数据", path: "/table/base" }
            ]
          }, 
          { title: "书籍管理", path: "/book", icon: "fa-table",
            child: [
              { title: "书籍数据", path: "/book/base" },
              { title: "评论管理", path: "/book/base" },
              { title: "推荐设置", path: "/book/base" },
              { title: "分类设置", path: "/book/base" }
            ]
          },
          { title: "数据统计",  path: "/charts", icon: "fa-bar-chart-o",
            child: [
              { title: "柱状图表", path: "/charts/bar" }
            ]
          },
          { title: "系统管理",  path: "/system", icon: "fa-bar-chart-o",
            child: [
              { title: "用户管理", path: "/charts/bar" },
              { title: "角色管理", path: "/charts/bar" }
            ]
          }
        ]
      }
    }
  }
</script>
