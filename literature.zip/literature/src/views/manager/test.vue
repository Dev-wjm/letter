<template>
  <div id="permission">
    <el-row>
      <el-col :span="2">
        <label for="rolename" style="text-align: right">角色名称：</label>  
      </el-col>
      <el-col :span="5">
        <el-input v-model="rolename" id="rolename"></el-input>
      </el-col>
    </el-row>
    <div id="authorityList">
      <el-tree :data="data2" show-checkbox node-key="id" ref="tree" :default-checked-keys="defaultKey" :props="defaultProps">
      </el-tree>
    </div>
    <div>
      <el-button>返回</el-button>
      <el-button type="primary" @click="authority">授权</el-button>
      
    </div>
  </div>
</template>

<script>
  import {createPermission} from '@/views/common/common'

  export default {
    name: "permissionDetail",
    data() {
      return {
        rolename: "",
        data2: [ 
          createPermission({id: 11,label: '用户管理'}),createPermission({id: 21,label: '书籍管理'}),createPermission({id: 31,label: '书评管理'}),createPermission({id: 41,label: '系统管理'})
        ],
        defaultProps: {
          children: 'children',
          label: 'label'
        },
        defaultKey: []
      }
    },
    created: function () {
      // this.fetchData();
    },
    methods: {
      fetchData() {
        // const _this = this;
        // getPermission({"id":this.$route.params.id}).then(data => {
        //   const _len = data.data.data.pIds.length;
        //   let { status, msg, roles } = data;
        //   if (status !==  200) {
        //     this.$message({
        //       message: roles.msg,
        //       type: 'error'
        //     });
        //   } else {
        //     _this.rolename = data.data.data.description;
        //     data.data.data.pIds.forEach(function(ele,index){
        //       _this.defaultKey.push(parseInt(data.data.data.pIds[index].id));  
        //     });  
        //     this.$refs.tree.setCheckedKeys(this.defaultKey);
        //   }
        // });
      },
      authority() {
        const params = {"rolename":this.rolename,"authority":this.$refs.tree.getCheckedKeys()};
        
        console.log(params)
        // updatePermission(params).then(data => {
        //   console.log(data)
        // });
      }
    }
  }
</script>