<template>
  <div class="panel">
    
    <div class="panel-title">
      <span>数据修改</span>
      <div class="fr">
        <router-link :to="{name: 'tableAdd'}" tag="span">
          <el-button type="primary" icon="plus" size="small">添加数据</el-button>
        </router-link>
      </div>
    </div>
    <div class="panel-body"
         v-loading="load_data"
         element-loading-text="拼命加载中">
      <el-row>
        <el-col :span="16">
          <el-form ref="form" :model="form" :rules="rules" label-width="100px">
            <el-row>
              <el-col>
                <el-form-item label="头像设置" prop="name">
                  <el-upload
                    class="avatar-uploader"
                    action="https://jsonplaceholder.typicode.com/posts/"
                    :show-file-list="false"
                    :on-success="handleAvatarSuccess"
                    :before-upload="beforeAvatarUpload">
                    <img v-if="imageUrl" :src="imageUrl" class="avatar">
                    <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                  </el-upload>
              </el-form-item>
              </el-col>
            </el-row>
            <el-form-item label="用户名:" prop="name">
              <el-input v-model="form.name" placeholder="请输入内容" style="width: 250px;"></el-input>
            </el-form-item>
            <el-form-item label="性别:">
              <el-radio-group v-model="form.sex">
                <el-radio :label="1">男</el-radio>
                <el-radio :label="2">女</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="长居地:" prop="name">
              <el-cascader size="large" :options="options" v-model="address"> </el-cascader>
            </el-form-item>
            <el-form-item label="电子邮箱:" prop="name">
              <el-input v-model="form.name" placeholder="请输入内容" style="width: 250px;"></el-input>
            </el-form-item>
            <el-form-item label="联系方式:" prop="name">
              <el-input v-model="form.name" placeholder="请输入内容" style="width: 250px;"></el-input>
            </el-form-item>
            <el-form-item label="年龄:">
              <el-input-number placeholder="请输入内容" :max="100" :min="1"  :controls="false" v-model="form.age" style="width: 250px;">
              </el-input-number>
            </el-form-item>
            <el-form-item label="生日:">
              <el-date-picker v-model="form.birthday" type="date" format="yyyy-MM-dd" :editable="false" @change="on_change_birthday" placeholder="选择生日"  style="width: 250px;">
              </el-date-picker>
            </el-form-item>
            <el-form-item label="邮编:">
              <el-input placeholder="请输入内容" :value="412300" :controls="false" v-model="form.zip" style="width: 250px;" :maxlength="6"  :minlength="6">
              </el-input>
            </el-form-item>
            <el-form-item label="喜欢的文学类型:" prop="type" label-width="120px">
              <el-checkbox-group v-model="form.type">
                <el-checkbox label="古典" name="type"></el-checkbox>
                <el-checkbox label="网络文学" name="type"></el-checkbox>
                <el-checkbox label="散文" name="type"></el-checkbox>
                <el-checkbox label="哲学" name="type"></el-checkbox>
                <el-checkbox label="其他" name="type"></el-checkbox>
                <el-checkbox label="散文" name="type"></el-checkbox>
                <el-checkbox label="哲学" name="type"></el-checkbox>
                <el-checkbox label="其他" name="type"></el-checkbox>
              </el-checkbox-group>
            </el-form-item>
            <el-form-item label="个人简介" prop="desc">
              <el-input type="textarea" v-model="form.desc"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="on_submit_form" :loading="on_submit_loading">立即提交</el-button>
              <el-button @click="$router.back()">取消</el-button>
            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script type="text/javascript">
import { regionData  } from 'element-china-area-data'

  export default{
    data(){
      return {
        options: regionData,
        address: [],
        imageUrl: '',
        form: {
          name: 'TEST',
          sex: 1,
          age: 20,
          birthday: '2018-02-11',
          address: 'address',
          zip: 412300,
          type: [],
          desc: ''
        },
        route_id: this.$route.params.id,
        load_data: false,
        on_submit_loading: false,
        rules: {
          name: [{required: true, message: '姓名不能为空', trigger: 'blur'}]
        }
      }
    },
    created(){
      
    },
    methods: {
      //获取数据
      get_form_data(){
        
      },
      //时间选择改变时
      on_change_birthday(val){
        this.$set(this.form, 'birthday', val)
      },
      //提交
      on_submit_form(){

      },
      // 头像上传方法
      handleAvatarSuccess(res, file) {
        this.imageUrl = URL.createObjectURL(file.raw);
      },
      beforeAvatarUpload(file) {
        const isJPG = file.type === 'image/jpeg';
        const isLt2M = file.size / 1024 / 1024 < 2;

        if (!isJPG) {
          this.$message.error('上传头像图片只能是 JPG 格式!');
        }
        if (!isLt2M) {
          this.$message.error('上传头像图片大小不能超过 2MB!');
        }
        return isJPG && isLt2M;
      }
    }
  }
</script>

<style>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>

