import Vue from 'vue'
import Router from 'vue-router'

// 公共页面组件
import Index from '@/views/index'

// 管理员页面组件
import A_login from '@/views/manager/login'
import A_home from 'manager/home'
import A_center from 'manager/center'
import UserList from 'manager/userList'
import A_user from 'manager/user'
import BookList from 'manager/bookList'
import Book from 'manager/book'
import Nominate from 'manager/nominate'
import A_commentList from 'manager/commentList'
import A_comment from 'manager/comment'
import Type from 'manager/type'
import RoleList from 'manager/roleList'
import PermissionList from 'manager/permissionList'

// 用户页面组件
import U_login from '@/views/customer/login';
import U_home from '@/views/customer/home'
import U_center from 'cust/center'
import U_user from 'cust/user'
import U_book from 'cust/bookList'
import U_commentLisk from 'cust/commentList'
import U_comment from 'cust/comment'


import Test from 'manager/test'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: '首页',
      component: Index
    },
    {
      path: '/alogin',
      name: '管理员登陆',
      component: A_login
    },
    {
      path: '/aindex',
      name: "后台管理",
      component: A_home,
      children: [
        { path:'/acenter', name:"管理员个人中心", component:A_center },
        { path:'/userList', name:"用户数据", component:UserList },
        { path:'/user/:id', name:"数据修改", component:A_user },
        { path:'/bookList', name:"书籍列表", component:BookList },
        { path:'/book/:id', name:"书籍", component:Book },
        { path:'/nominate', name:"推荐设置", component:Nominate },
        { path:'/commentList', name:"评论数据", component:A_commentList },
        { path:'/comment/:id', name:"评论", component: A_comment },
        { path:'/type', name:"类型设置", component:Type },
        { path:'/roleList', name:"用户角色", component:RoleList },
        { path:'/permissionList', name:"角色权限", component:PermissionList } 
      ]

    },
    {
      path: '/ulogin',
      name: '用户登陆',
      component: U_login
    },
    {
      path: '/uindex',
      name: "用户首页",
      component: U_home,
      children: [
        { path:'/ucenter', name:"用户个人中心", component:U_center },
        { path:'/uuser', name:"个人信息", component:U_user },
        { path:'/ubook', name:"收藏书籍", component:U_book },
        { path:'/ucommentList', name:"个人评论", component:U_commentLisk },
        { path:'/ucomment/:id', name:"评论详情", component:U_comment }
      ]
     }
  ]
})
