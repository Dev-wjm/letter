import Vuex from 'vuex'
import Vue from 'vue'

Vue.use(Vuex)

const store = new Vuex.Store({
  state: {
    count: 0
  },
  mutations: {
    increment (state) {
      state.count++
    }
  },
  actions: {
    increment (context,_this) {
      console.log(_this.$ruoter.push("/acenter"))
      console.log(context)
      console.log("action test")
      console.log(this);
      console.log(this._vm);
    }
  }
})

export default store;